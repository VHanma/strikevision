# Hanma Anatomy 3D

Android offline procedural 3D anatomy atlas.

## Included
- Rotatable and zoomable 3D body
- Tap-to-select muscles with action, origin, insertion and innervation
- 3D muscle-group demonstrations
- Fascia / myofascial chain explorer
- Combat biomechanics tab with activation cascades
- Layer explorer: muscle, fascia, skeleton, kinetic paths
- No account, no cloud dependency, no external JS dependency

## Fascia / kinetic lines included
Superficial Back Line, Superficial Front Line, Spiral Line, Front Functional Line,
Back Functional Line, Lateral Line, Deep Front Line and Arm Line.

## Build
Open in Android Studio (JDK 17+), sync, build APK.
Package: com.vhanma.anatomy3d
Min SDK: 26
Target/compile SDK: 35
